﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player1 : MonoBehaviour {
    public float speedX, speedY;
    Rigidbody2D rb;
    public GameObject stone, coin;
    public Vector3 position;
    public static bool conditionSpark = true, conditionCoin = true;
    public int pontos = 0, vidas = 3;
    public Text pts, lfs;

	// Use this for initialization
	void Start () {
        rb = GetComponent<Rigidbody2D>();        
        spawnaCoin();
        spawnaSpark();
	}

    void spawnaCoin()
    {
        if (Player1.conditionCoin == true)
        {
            for (float x = -9; x < 0; x += 4.5f)
            {
                position = new Vector3(x, 6f, 0f);
                Instantiate(coin, position, Quaternion.identity);
            }
            Player1.conditionCoin = false;
        }
    }

    void spawnaSpark()
    {
        if (Player1.conditionSpark == true)
        {
            for (float x = -10; x < 0; x += 2.5f)
            {
                position = new Vector3(x, 6f, 0f);
                Instantiate(stone, position, Quaternion.identity);
            }
            Player1.conditionSpark = false;
        }
    }

	// Update is called once per frame
	void Update () {

        pts.text = "Pontos " + pontos.ToString();
        lfs.text = "Vidas " + vidas.ToString();

        spawnaCoin();
        spawnaSpark();

        speedX = Input.GetAxis("Horizontal");
        speedY = Input.GetAxis("Vertical");

        rb.velocity = new Vector2(speedX * 2.5f, speedY * 2.5f);
	}

    void OnCollisionEnter2D(Collision2D col)
    {
        if (col.gameObject.tag == "Spark")
        {
            if (vidas >= 1)
            {
                vidas--;
            }
            else
            {
                Destroy(this.gameObject);
                lfs.text = "You die!!!";
            }
        }

        if (col.gameObject.tag == "Coin")
        {
            pontos++;
            Destroy(col.gameObject);
        }
    }

}
